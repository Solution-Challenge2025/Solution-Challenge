import React from 'react';
import CourseCard from '../components/CourseCard';
import UserProgress from '../components/UserProgress';
import Header from '../components/Header';
import { Book, Users, Globe } from 'lucide-react';

export const mockUser = {
  name: "John Smith",
  level: "Class 6",
  points: 850,
  coursesEnrolled: 6,
  badges: [
    "Math Wizard",
    "Science Explorer",
    "Language Master",
    "Perfect Attendance",
    "Quiz Champion",
    "Top Performer"
  ],
  rank: 3,
  quizzesCompleted: 24,
  averageScore: 92,
  subjectProgress: {
    Telugu: 75,
    Hindi: 60,
    English: 85,
    Mathematics: 70,
    Science: 80,
    Social: 65
  }
};

export const mockCourses = [
  // LKG Courses
  {
    id: "lkg-english",
    title: "LKG - English",
    description: "Learn basic English alphabets and phonics",
    level: "beginner",
    language: "English",
    thumbnail: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    category: "LKG"
  },
  {
    id: "lkg-maths",
    title: "LKG - Mathematics",
    description: "Introduction to numbers and counting",
    level: "beginner",
    language: "English",
    thumbnail: "https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    category: "LKG"
  },
  {
    id: "lkg-rhymes",
    title: "LKG - Rhymes",
    description: "Fun nursery rhymes and songs",
    level: "beginner",
    language: "English",
    thumbnail: "https://images.unsplash.com/photo-1445633629932-0029acc44e88?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    category: "LKG"
  },

  // UKG Courses
  {
    id: "ukg-english",
    title: "UKG - English",
    description: "Advanced alphabets and simple words",
    level: "beginner",
    language: "English",
    thumbnail: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    category: "UKG"
  },
  {
    id: "ukg-maths",
    title: "UKG - Mathematics",
    description: "Numbers up to 100 and basic addition",
    level: "beginner",
    language: "English",
    thumbnail: "https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    category: "UKG"
  },
  {
    id: "ukg-evs",
    title: "UKG - Environmental Science",
    description: "Basic environmental awareness",
    level: "beginner",
    language: "English",
    thumbnail: "https://images.unsplash.com/photo-1530538987395-032d1800fdd0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    category: "UKG"
  },

  // Existing courses...
  {
    id: "1st-telugu",
    title: "1st Class - Telugu",
    description: "Learn Telugu alphabets, words, and basic grammar",
    level: "beginner",
    language: "Telugu",
    thumbnail: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    category: "1st Class"
  },
  // ... rest of your existing courses
];

export default function HomePage() {
  const [selectedCategory, setSelectedCategory] = React.useState(mockUser.level);

  const filteredCourses = mockCourses.filter(course => course.category === selectedCategory);

  const classLevels = [
    "LKG", "UKG",
    "1st Class", "2nd Class", "3rd Class", "4th Class", "5th Class",
    "6th Class", "7th Class", "8th Class", "9th Class", "10th Class"
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Sidebar - User Progress */}
          <div className="lg:col-span-1">
            <UserProgress user={mockUser} />
            
            <div className="mt-8 bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold mb-4">Learning Statistics</h2>
              <div className="space-y-4">
                <div className="flex items-center">
                  <Book className="w-5 h-5 text-indigo-600 mr-3" />
                  <div>
                    <p className="text-sm text-gray-600">Active Subjects</p>
                    <p className="text-lg font-semibold">6</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Users className="w-5 h-5 text-indigo-600 mr-3" />
                  <div>
                    <p className="text-sm text-gray-600">Students Learning</p>
                    <p className="text-lg font-semibold">10,000+</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Globe className="w-5 h-5 text-indigo-600 mr-3" />
                  <div>
                    <p className="text-sm text-gray-600">Languages</p>
                    <p className="text-lg font-semibold">3</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content - Course Grid */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-gray-900">Learning Materials</h2>
              </div>
              <div className="flex flex-wrap gap-2 mb-6">
                {classLevels.map((level) => (
                  <button 
                    key={level}
                    onClick={() => setSelectedCategory(level)}
                    className={`px-4 py-2 rounded-full ${
                      selectedCategory === level
                        ? "bg-indigo-600 text-white" 
                        : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredCourses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}