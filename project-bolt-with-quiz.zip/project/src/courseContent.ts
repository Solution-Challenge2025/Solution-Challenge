export const courseContent = {
  // LKG Content
  'lkg-english': {
    title: 'English - LKG',
    sections: [
      {
        title: 'Alphabets A-E',
        description: 'Learn the first five letters with fun activities',
        type: 'video',
        duration: '15 min',
        content: {
          letters: [
            { letter: 'A', sound: '/æ/', example: 'Apple, Ant, Axe' },
            { letter: 'B', sound: '/b/', example: 'Ball, Bat, Boy' },
            { letter: 'C', sound: '/k/', example: 'Cat, Cap, Cup' },
            { letter: 'D', sound: '/d/', example: 'Dog, Doll, Duck' },
            { letter: 'E', sound: '/ɛ/', example: 'Egg, Elephant, End' }
          ]
        }
      },
      {
        title: 'Nursery Rhymes',
        description: 'Popular nursery rhymes with actions',
        type: 'interactive',
        duration: '20 min',
        content: {
          rhymes: [
            { title: 'Twinkle Twinkle', lyrics: 'Twinkle twinkle little star...' },
            { title: 'Baa Baa Black Sheep', lyrics: 'Baa baa black sheep...' }
          ]
        }
      }
    ]
  },

  // UKG Content
  'ukg-english': {
    title: 'English - UKG',
    sections: [
      {
        title: 'Simple Words',
        description: 'Learn to read and write simple words',
        type: 'interactive',
        duration: '25 min',
        content: {
          words: [
            { word: 'cat', phonics: 'c-a-t', example: 'The cat is black.' },
            { word: 'dog', phonics: 'd-o-g', example: 'The dog runs fast.' },
            { word: 'sun', phonics: 's-u-n', example: 'The sun is bright.' }
          ]
        }
      },
      {
        title: 'Basic Sentences',
        description: 'Form simple sentences',
        type: 'activity',
        duration: '30 min',
        content: {
          sentences: [
            { subject: 'I', verb: 'am', object: 'happy' },
            { subject: 'She', verb: 'is', object: 'reading' },
            { subject: 'They', verb: 'are', object: 'playing' }
          ]
        }
      }
    ]
  },

  // Hindi Content for all classes
  '1st-hindi': {
    title: 'Hindi - Class 1',
    sections: [
      {
        title: 'Hindi Vowels (स्वर)',
        description: 'Learn Hindi vowels with pronunciation',
        type: 'video',
        duration: '15 min',
        content: {
          vowels: [
            { letter: 'अ', pronunciation: 'a', example: 'अनार (anaar - pomegranate)' },
            { letter: 'आ', pronunciation: 'aa', example: 'आम (aam - mango)' },
            { letter: 'इ', pronunciation: 'i', example: 'इमली (imli - tamarind)' }
          ]
        }
      },
      {
        title: 'Basic Words',
        description: 'Learn simple Hindi words',
        type: 'interactive',
        duration: '20 min',
        content: {
          words: [
            { word: 'माता', meaning: 'mother', pronunciation: 'maata' },
            { word: 'पिता', meaning: 'father', pronunciation: 'pita' }
          ]
        }
      }
    ]
  },

  // English Content
  '1st-english': {
    title: 'English - Class 1',
    sections: [
      {
        title: 'Alphabets',
        description: 'Learn English alphabets with phonics',
        type: 'video',
        duration: '15 min',
        content: {
          letters: [
            { letter: 'A', sound: '/æ/', example: 'Apple, Ant, Axe' },
            { letter: 'B', sound: '/b/', example: 'Ball, Bat, Boy' }
          ]
        }
      }
    ]
  },

  // Mathematics Content
  '1st-maths': {
    title: 'Mathematics - Class 1',
    sections: [
      {
        title: 'Numbers 1-10',
        description: 'Learn to count from 1 to 10',
        type: 'interactive',
        duration: '20 min',
        content: {
          numbers: [
            { number: 1, word: 'One', objects: ['🍎'] },
            { number: 2, word: 'Two', objects: ['🍎', '🍎'] }
          ]
        }
      }
    ]
  },

  // Science Content
  '1st-science': {
    title: 'Science - Class 1',
    sections: [
      {
        title: 'Living Things',
        description: 'Learn about living and non-living things',
        type: 'video',
        duration: '20 min',
        content: {
          examples: [
            { type: 'Living', items: ['Plants', 'Animals', 'Humans'] },
            { type: 'Non-living', items: ['Rocks', 'Chair', 'Table'] }
          ]
        }
      }
    ]
  },

  // Social Studies Content
  '1st-social': {
    title: 'Social Studies - Class 1',
    sections: [
      {
        title: 'My Family',
        description: 'Learn about family members and relationships',
        type: 'interactive',
        duration: '25 min',
        content: {
          relationships: [
            { name: 'Mother', role: 'Takes care of the family' },
            { name: 'Father', role: 'Protects and provides for the family' }
          ]
        }
      }
    ]
  },

  // 10th Class Content Examples
  '10th-maths': {
    title: 'Mathematics - Class 10',
    sections: [
      {
        title: 'Trigonometry',
        description: 'Learn trigonometric ratios and identities',
        type: 'video',
        duration: '45 min',
        content: {
          topics: [
            'Sine, Cosine, Tangent',
            'Trigonometric Identities',
            'Height and Distance'
          ]
        }
      }
    ]
  },

  '10th-science': {
    title: 'Science - Class 10',
    sections: [
      {
        title: 'Chemical Reactions',
        description: 'Understanding different types of chemical reactions',
        type: 'interactive',
        duration: '40 min',
        content: {
          reactions: [
            'Combination Reactions',
            'Decomposition Reactions',
            'Displacement Reactions'
          ]
        }
      }
    ]
  }
};