export interface Course {
  id: string;
  title: string;
  description: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  language: string;
  thumbnail: string;
  progress?: number;
  category: string;
}

export interface User {
  name: string;
  level: string;
  points: number;
  coursesEnrolled: number;
  badges: string[];
  rank: number;
  quizzesCompleted: number;
  averageScore: number;
  subjectProgress: {
    [key: string]: number;
  };
}

export interface Quiz {
  id: string;
  title: string;
  description: string;
  timeLimit: number; // in minutes
  questions: QuizQuestion[];
  class: string;
  subject: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface QuizResult {
  userId: string;
  quizId: string;
  score: number;
  totalQuestions: number;
  timeTaken: number;
  date: string;
}

export interface LeaderboardEntry {
  userId: string;
  userName: string;
  totalScore: number;
  quizzesTaken: number;
  averageScore: number;
  rank: number;
}