import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, PlayCircle, BookOpen, PenTool, X } from 'lucide-react';
import { courseContent } from '../courseContent';
import QuizComponent from './QuizComponent';

export default function CourseViewer() {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const course = courseContent[courseId as keyof typeof courseContent];
  const [selectedSection, setSelectedSection] = useState<number | null>(null);

  const getIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <PlayCircle className="w-6 h-6 text-indigo-600 mr-3" />;
      case 'interactive':
        return <BookOpen className="w-6 h-6 text-green-600 mr-3" />;
      case 'activity':
        return <PenTool className="w-6 h-6 text-orange-600 mr-3" />;
      default:
        return <PlayCircle className="w-6 h-6 text-indigo-600 mr-3" />;
    }
  };

  const renderSectionContent = (section: any, index: number) => {
    if (index !== selectedSection) return null;

    switch (section.type) {
      case 'video':
        return (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-semibold mb-2">Video Content</h4>
            <div className="aspect-w-16 aspect-h-9 bg-black rounded-lg flex items-center justify-center text-white">
              {section.content?.vowels && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4 p-4">
                  {section.content.vowels.map((vowel: any, i: number) => (
                    <div key={i} className="bg-white p-4 rounded-lg shadow">
                      <div className="text-4xl font-bold text-indigo-600 mb-2">{vowel.letter}</div>
                      <div className="text-gray-800 text-sm">
                        <p>Pronunciation: {vowel.pronunciation}</p>
                        <p>Example: {vowel.example}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {!section.content?.vowels && "Video content will be displayed here"}
            </div>
          </div>
        );
      case 'interactive':
        return (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-semibold mb-4">{section.title}</h4>
            {section.content?.words && (
              <div className="grid grid-cols-2 gap-4">
                {section.content.words.map((word: any, i: number) => (
                  <div key={i} className="bg-white p-4 rounded-lg shadow">
                    <div className="text-2xl font-bold text-indigo-600 mb-2">{word.word}</div>
                    <div className="text-sm">
                      <p>Meaning: {word.meaning}</p>
                      <p>Pronunciation: {word.pronunciation}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
            {section.content?.numbers && (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {section.content.numbers.map((num: any, i: number) => (
                  <div key={i} className="bg-white p-4 rounded-lg shadow text-center">
                    <div className="text-4xl font-bold text-indigo-600 mb-2">{num.number}</div>
                    <div className="text-xl mb-2">{num.word}</div>
                    <div className="text-2xl">{num.objects.join(' ')}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  if (!course) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <button 
          onClick={() => navigate('/')}
          className="flex items-center text-indigo-600 hover:text-indigo-800 mb-6"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Courses
        </button>
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
          <h1 className="text-2xl font-bold text-gray-900">Course Not Found</h1>
          <p className="text-gray-600 mt-2">This course is currently under development.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <button 
        onClick={() => navigate('/')}
        className="flex items-center text-indigo-600 hover:text-indigo-800 mb-6"
      >
        <ArrowLeft className="w-5 h-5 mr-2" />
        Back to Courses
      </button>
      
      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-6">
          <h1 className="text-2xl font-bold mb-4">{course.title}</h1>
          <div className="space-y-4">
            {course.sections.map((section, index) => (
              <div key={index}>
                <div 
                  className="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                  onClick={() => setSelectedSection(selectedSection === index ? null : index)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      {getIcon(section.type)}
                      <div>
                        <h3 className="font-medium">{section.title}</h3>
                        <p className="text-sm text-gray-600">{section.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <span className="text-sm text-gray-500 mr-3">{section.duration}</span>
                      {selectedSection === index ? (
                        <X className="w-5 h-5 text-gray-400" />
                      ) : (
                        <PlayCircle className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                  </div>
                </div>
                {renderSectionContent(section, index)}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}