import React from 'react';
import { Trophy, Medal, Award } from 'lucide-react';
import { LeaderboardEntry } from '../types';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface LeaderboardProps {
  entries: LeaderboardEntry[];
  selectedClass?: string;
  selectedSubject?: string;
}

const getRankIcon = (rank: number) => {
  switch (rank) {
    case 1:
      return <Trophy className="w-8 h-8 text-yellow-500" />;
    case 2:
      return <Medal className="w-8 h-8 text-gray-400" />;
    case 3:
      return <Award className="w-8 h-8 text-amber-700" />;
    default:
      return null;
  }
};

export default function Leaderboard({ entries, selectedClass, selectedSubject }: LeaderboardProps) {
  const chartData = {
    labels: entries.slice(0, 10).map(entry => entry.userName),
    datasets: [
      {
        label: 'Average Score',
        data: entries.slice(0, 10).map(entry => entry.averageScore),
        backgroundColor: 'rgba(99, 102, 241, 0.5)',
        borderColor: 'rgb(99, 102, 241)',
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Top 10 Students Performance',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
      },
    },
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900">
          Leaderboard
          {selectedClass && ` - ${selectedClass}`}
          {selectedSubject && ` (${selectedSubject})`}
        </h2>
        <p className="text-gray-600">Top performers based on quiz scores</p>
      </div>

      <div className="mb-8">
        <Bar data={chartData} options={chartOptions} />
      </div>

      <div className="space-y-4">
        {entries.map((entry) => (
          <div
            key={entry.userId}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <div className="flex items-center space-x-4">
              <div className="flex-shrink-0">
                {getRankIcon(entry.rank)}
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">{entry.userName}</h3>
                <p className="text-sm text-gray-600">
                  Quizzes taken: {entry.quizzesTaken}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-indigo-600">
                {entry.averageScore.toFixed(1)}%
              </p>
              <p className="text-sm text-gray-600">
                Total Score: {entry.totalScore}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}