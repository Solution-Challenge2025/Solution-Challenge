import React from 'react';
import { Book, BookOpen, Calculator, FlaskRound as Flask, Globe, Languages } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const subjects = [
  { name: 'Telugu', icon: <Languages className="w-5 h-5" />, color: 'text-purple-600' },
  { name: 'Hindi', icon: <Languages className="w-5 h-5" />, color: 'text-pink-600' },
  { name: 'English', icon: <Book className="w-5 h-5" />, color: 'text-blue-600' },
  { name: 'Mathematics', icon: <Calculator className="w-5 h-5" />, color: 'text-green-600' },
  { name: 'Science', icon: <Flask className="w-5 h-5" />, color: 'text-red-600' },
  { name: 'Social', icon: <Globe className="w-5 h-5" />, color: 'text-yellow-600' }
];

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const navigate = useNavigate();

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-full w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out z-50 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-bold text-gray-800">Subjects</h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>

          <nav className="space-y-2">
            {subjects.map((subject) => (
              <button
                key={subject.name}
                onClick={() => {
                  navigate(`/subjects/${subject.name.toLowerCase()}`);
                  onClose();
                }}
                className="flex items-center w-full px-4 py-3 text-left rounded-lg hover:bg-gray-100 transition-colors"
              >
                <span className={`${subject.color} mr-3`}>{subject.icon}</span>
                <span className="text-gray-700">{subject.name}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>
    </>
  );
}