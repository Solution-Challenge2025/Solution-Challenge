import React, { useState, useEffect } from 'react';
import { Quiz, QuizQuestion } from '../types';
import { Clock, CheckCircle, XCircle } from 'lucide-react';

interface QuizComponentProps {
  quiz: Quiz;
  onComplete: (score: number, timeTaken: number) => void;
}

export default function QuizComponent({ quiz, onComplete }: QuizComponentProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);
  const [timeLeft, setTimeLeft] = useState(quiz.timeLimit * 60);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    if (timeLeft > 0 && !isCompleted) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0 && !isCompleted) {
      handleQuizComplete();
    }
  }, [timeLeft, isCompleted]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleAnswerSelect = (answerIndex: number) => {
    if (!showExplanation) {
      setSelectedAnswer(answerIndex);
    }
  };

  const handleNext = () => {
    if (selectedAnswer === quiz.questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
    
    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      handleQuizComplete();
    }
  };

  const handleQuizComplete = () => {
    setIsCompleted(true);
    const timeTaken = quiz.timeLimit * 60 - timeLeft;
    onComplete(score, timeTaken);
  };

  if (isCompleted) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold mb-4">Quiz Completed!</h2>
        <div className="text-center">
          <div className="text-6xl font-bold text-indigo-600 mb-4">
            {Math.round((score / quiz.questions.length) * 100)}%
          </div>
          <p className="text-gray-600 mb-2">
            You scored {score} out of {quiz.questions.length} questions
          </p>
          <p className="text-gray-600">
            Time taken: {formatTime(quiz.timeLimit * 60 - timeLeft)}
          </p>
        </div>
      </div>
    );
  }

  const currentQuestionData = quiz.questions[currentQuestion];

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">{quiz.title}</h2>
        <div className="flex items-center text-gray-600">
          <Clock className="w-5 h-5 mr-2" />
          {formatTime(timeLeft)}
        </div>
      </div>

      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Question {currentQuestion + 1} of {quiz.questions.length}</span>
          <span>Score: {score}</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-indigo-600 h-2 rounded-full transition-all"
            style={{ width: `${((currentQuestion + 1) / quiz.questions.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="mb-8">
        <h3 className="text-lg font-medium mb-4">{currentQuestionData.question}</h3>
        <div className="space-y-3">
          {currentQuestionData.options.map((option, index) => (
            <button
              key={index}
              className={`w-full p-4 text-left rounded-lg border transition-colors ${
                selectedAnswer === index
                  ? showExplanation
                    ? index === currentQuestionData.correctAnswer
                      ? 'bg-green-100 border-green-500'
                      : 'bg-red-100 border-red-500'
                    : 'bg-indigo-100 border-indigo-500'
                  : 'border-gray-200 hover:bg-gray-50'
              }`}
              onClick={() => handleAnswerSelect(index)}
              disabled={showExplanation}
            >
              <div className="flex items-center">
                {showExplanation && selectedAnswer === index && (
                  index === currentQuestionData.correctAnswer
                    ? <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                    : <XCircle className="w-5 h-5 text-red-500 mr-2" />
                )}
                {option}
              </div>
            </button>
          ))}
        </div>
      </div>

      {selectedAnswer !== null && !showExplanation && (
        <button
          className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors"
          onClick={() => setShowExplanation(true)}
        >
          Check Answer
        </button>
      )}

      {showExplanation && (
        <div className="mt-4">
          <div className={`p-4 rounded-lg ${
            selectedAnswer === currentQuestionData.correctAnswer
              ? 'bg-green-100 text-green-800'
              : 'bg-red-100 text-red-800'
          }`}>
            <p className="font-medium mb-2">
              {selectedAnswer === currentQuestionData.correctAnswer
                ? 'Correct!'
                : 'Incorrect!'}
            </p>
            <p>{currentQuestionData.explanation}</p>
          </div>
          <button
            className="w-full mt-4 bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors"
            onClick={handleNext}
          >
            {currentQuestion < quiz.questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
          </button>
        </div>
      )}
    </div>
  );
}