import React from 'react';
import { Award, BookOpen, Trophy, Star, Target, Medal } from 'lucide-react';
import { User } from '../types';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface UserProgressProps {
  user: User;
}

export default function UserProgress({ user }: UserProgressProps) {
  const subjectProgress = {
    Telugu: 75,
    Hindi: 60,
    English: 85,
    Mathematics: 70,
    Science: 80,
    Social: 65
  };

  const chartData = {
    labels: Object.keys(subjectProgress),
    datasets: [
      {
        label: 'Subject Completion (%)',
        data: Object.values(subjectProgress),
        fill: false,
        borderColor: 'rgb(99, 102, 241)',
        tension: 0.1
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Subject Progress'
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100
      }
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center">
          <Trophy className="w-10 h-10 text-indigo-600" />
        </div>
        <div className="ml-4">
          <h2 className="text-2xl font-semibold">{user.name}</h2>
          <p className="text-gray-600">{user.level}</p>
          <p className="text-sm text-indigo-600">Rank #{user.rank} Overall</p>
        </div>
      </div>

      <div className="mb-8">
        <Line data={chartData} options={chartOptions} />
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="flex items-center p-4 bg-indigo-50 rounded-lg">
          <BookOpen className="w-6 h-6 text-indigo-600" />
          <div className="ml-3">
            <p className="text-sm text-gray-600">Active Courses</p>
            <p className="text-lg font-semibold">{user.coursesEnrolled}</p>
          </div>
        </div>
        <div className="flex items-center p-4 bg-indigo-50 rounded-lg">
          <Star className="w-6 h-6 text-indigo-600" />
          <div className="ml-3">
            <p className="text-sm text-gray-600">Points</p>
            <p className="text-lg font-semibold">{user.points}</p>
          </div>
        </div>
        <div className="flex items-center p-4 bg-indigo-50 rounded-lg">
          <Target className="w-6 h-6 text-indigo-600" />
          <div className="ml-3">
            <p className="text-sm text-gray-600">Quizzes Completed</p>
            <p className="text-lg font-semibold">{user.quizzesCompleted}</p>
          </div>
        </div>
        <div className="flex items-center p-4 bg-indigo-50 rounded-lg">
          <Medal className="w-6 h-6 text-indigo-600" />
          <div className="ml-3">
            <p className="text-sm text-gray-600">Average Score</p>
            <p className="text-lg font-semibold">{user.averageScore}%</p>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Subject Progress</h3>
        <div className="space-y-4">
          {Object.entries(subjectProgress).map(([subject, progress]) => (
            <div key={subject}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700">{subject}</span>
                <span className="text-sm text-gray-600">{progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-indigo-600 h-2 rounded-full"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium text-gray-900 mb-4">Badges Earned</h3>
        <div className="grid grid-cols-2 gap-4">
          {user.badges.map((badge, index) => (
            <div
              key={index}
              className="flex items-center p-3 bg-indigo-50 rounded-lg"
            >
              <Award className="w-5 h-5 text-indigo-600" />
              <span className="ml-2 text-sm font-medium text-gray-800">{badge}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}